# ESP32 BLE Gateway Dashboard

This is the server application for the ESP32 BLE Gateway. It provides a web-based dashboard to monitor gateway status, view connected BLE devices, and send commands for OTA updates and WiFi configuration.

This repository hosts the **compiled releases** only. The source code is private.

## Features

  * **Real-time Monitoring:** View all gateways, their status (Connected, Idle, Disconnected), firmware version, and connected BLE devices.
  * **Performance Metrics:** Track throughput, WiFi/BLE RSSI, packet statistics, and battery levels with threshold-based alerts.
  * **Device Blacklist:** Manage a unified blacklist of devices across all gateways via MQTT.
  * **TCP Debug Logs:** Continuous collection of debug logs from gateway debug ports with persistent connections.
  * **OTA Updates:** Upload a new `firmware.bin` file and deploy it to a single gateway or all gateways.
  * **WiFi Configuration:** Remotely update the WiFi credentials (SSID/Password) for a gateway.
  * **Log Management:** View, download, and stream log files with filtering and auto-refresh capabilities.

## Release v1.2.1

This release adds enhanced gateway network visibility and improved BSSID binding controls.

### New Features

- **Network Connectivity Info in Modal**
  - New section in expanded gateway view showing: WiFi SSID, Access Point BSSID, Gateway IP, Gateway MAC, and BSSID Binding status
  - Displays green "✓ Bound" or gray "✗ Free" indicators for BSSID binding status

- **Enhanced CSV Binding Format**
  - CSV now requires 3 columns: `ESP_MAC, ROUTER_MAC, true/false`
  - Third column controls whether to bind (`true`) or unbind (`false`) from the BSSID
  - Preview table shows ✓/✗ icons for binding status

### Technical Details

- Updated MQTT command: `{"command":"wifi_bssid","bssid":"AP_MAC","use_bssid":true/false,"target_mac":"ESP32_MAC"}`
- New Device struct fields: `ssid`, `bssid`, `gatewayip`, `gatewaymac`, `isConnecttosetbssid`
- Frontend auto-populates network info from ESP32 status messages

## Release v1.2.0

This release introduces fleet management enhancements for large-scale deployments.

### New Features

- **WiFi Router MAC Binding**
  - New "Router Bind" tab in the Remote Connectivity card
  - Upload CSV files with ESP32 MAC → Router BSSID mappings
  - Bind specific gateways to designated WiFi access points for better network management
  - MQTT command format: `{"command":"wifi_bssid","bssid":"ROUTER_MAC","target_mac":"ESP32_MAC"}`

- **Reboot All Gateways**
  - New "Reboot All" button in the dashboard header
  - Fleet-wide reboot capability with confirmation dialog
  - Uses existing reboot command with `target_mac: "all"`

### Technical Details

- New API endpoint: `POST /api/command/router-binding`
- Router binding commands published to `gateways/command/broadcast` topic
- CSV format: Two columns (ESP32 MAC, Router MAC) with colon-separated MAC addresses
- Audit logging for all router binding and reboot commands

## Release v1.1.6

This release addresses a critical issue with OTA firmware updates in fleet deployments.

### Fixes

- **OTA Token Expiry & Reuse**:
  - Increased OTA token expiration time from 5 minutes to **30 minutes**.
  - Enabled **multi-use tokens**: A single generated OTA URL can now be used by multiple devices simultaneously or sequentially within the 30-minute window. This fixes the issue where only the first device in a fleet could update successfully.

## Release v1.1.3

This release introduces major enhancements to device management, log collection, and user interface improvements.

### New Features

- **Device Blacklist Management**
  - New blacklist card in dashboard for adding/removing devices
  - Bidirectional MQTT synchronization on topic `ble/blacklist`
  - Real-time updates across all dashboard instances
  - Unified blacklist format: `{"blacklist": ["device1", "device2"]}`

- **Persistent TCP Debug Log Collection**
  - TCP connections to gateway debug ports now stay alive indefinitely
  - Continuous log collection without periodic reconnections
  - Per-gateway debug logs with automatic daily rotation
  - Improved reliability for large gateway fleets

- **Enhanced Performance Metrics**
  - Throughput calculation from MQTT payload sizes
  - Average, minimum, and maximum BLE RSSI tracking
  - Packet statistics (total and average packets sent)
  - Threshold-based color-coded alerts for degraded performance
  - Hyper-informative device cards with key metrics visible at a glance

- **Improved Log Management**
  - Clickable table rows to open log viewer
  - Auto-refresh enabled by default when opening logs
  - Compact table layout with truncated filenames
  - Download button available in expanded log viewer

- **UI/UX Improvements**
  - More compact card layouts for better space utilization
  - Better organized expanded gateway view for laptop screens
  - Responsive design maintained for mobile devices
  - Flicker-free blacklist updates with intelligent change detection

### Technical Improvements

- Optimized TCP connection management with keepalive
- Improved WebSocket state synchronization
- Better error handling and logging
- Code cleanup and documentation updates

### Bug Fixes

- Fixed blacklist empty state display
- Fixed last element deletion bug in blacklist
- Improved MQTT message handling for blacklist updates
- Fixed log table horizontal scrolling issues

## Release v1.1.1

This release includes code cleanup, improved project structure, and preparation for automated releases via GoReleaser.

### Changes

- Project structure cleanup: test files moved to `tests/` directory
- Simulator moved to `cmd/simulator` for better organization
- Removed temporary documentation and AI support files
- Updated `.gitignore` for cleaner repository
- Improved GoReleaser configuration

## Release v1.1.0 Highlights

- Persisted metrics and metrics API (`/api/metrics`) for historical battery/temperature/voltage samples
- Date-range filtering for log streaming (`/api/logs/stream?file=...&from=...&to=...`)
- Centralized debug logging at `logs/debug/all-debug.log` in addition to per-device logs
- WebSocket debug trace broadcasting with per-client subscription filters
- Frontend enhancements: Performance charts and live log streaming

## Installation & First Run

1.  **Download:** Go to the [**Releases Page**](https://github.com/PD-dev-2025/gateway-dashboard-release/releases) and download the `.zip` file for your operating system (Windows, Linux, or macOS).

2.  **Unzip:** Extract the archive. You will have a folder containing:

      * `gateway-dashboard` (or `gateway-dashboard.exe`)
      * `config.json.example`
      * `README.md` (This file)

3.  **Configure (IMPORTANT):**

      * Rename `config.json.example` to `config.json`.
      * Open `config.json` in a text editor.
      * Change the `mqtt_broker` value to your MQTT broker's IP address and port (e.g., `tcp://192.168.1.100:1883`).
      * You can also change the `http_port` if needed.

4.  **Run:**

      * Open a terminal or command prompt.
      * Navigate to the folder containing the application.
      * Run the executable:
          * **On Linux/macOS:** `./gateway-dashboard`
          * **On Windows:** `gateway-dashboard.exe`

5.  **First-Time Setup (Security):**

      * The first time you run the app, it will generate a secure `master_key` and save it to your `config.json`.
      * Open your web browser and go to `http://YOUR_SERVER_IP:8080` (or the port you set).
      * The app will automatically redirect you to `/admin`.
      * **You must create your admin username and password here.** Use your `master_key` (from `config.json`) to authorize this change.
      * After setting your password, you will be redirected to the login page.

Log in with your new credentials to access the dashboard.

## Configuration

### MQTT Broker

The dashboard requires an MQTT broker to communicate with gateways. Configure the broker address in `config.json`:

```json
{
  "mqtt_broker": "tcp://YOUR_MQTT_BROKER_IP:1883"
}
```

### Device Blacklist

The blacklist is managed via the MQTT topic `ble/blacklist`. The dashboard automatically subscribes to this topic and keeps the local list synchronized. You can:

- Add/remove devices via the dashboard UI
- Publish blacklist updates directly to MQTT (format: `{"blacklist": ["device1", "device2"]}`)
- Changes from any source are automatically reflected across all dashboard instances

### TCP Debug Ports

Gateways can expose debug ports for continuous log collection. The dashboard automatically connects to these ports when a gateway's `debugport` field is set in MQTT messages. TCP connections are maintained indefinitely for reliable log collection.

## Upgrade Instructions

### From v1.1.1 or earlier

1. Stop the running dashboard server
2. Backup your `config.json` file
3. Download and extract the new release
4. Copy your `config.json` to the new directory
5. Start the new version

No database migrations or additional configuration required. The blacklist feature will be available immediately upon upgrade.

## Troubleshooting

### Blacklist not updating

- Ensure the MQTT broker is accessible
- Check that the dashboard is subscribed to `ble/blacklist` topic
- Verify MQTT message format: `{"blacklist": ["device1", "device2"]}`

### TCP Debug logs not appearing

- Verify gateway has `debugport` field set in MQTT messages
- Check firewall rules allow TCP connections to gateway debug ports
- Review server logs for connection errors

### Performance metrics not showing

- Ensure gateways are publishing to `ble/device/status` and `ble/device/data` topics
- Check that MQTT messages include required fields (RSSI, packet counts, etc.)
